insert into CALC_GROUP (NAME) VALUES("GROUP1");
insert into CALC_GROUP (NAME) VALUES("GROUP2");
insert into CALC_GROUP (NAME) VALUES("GROUP3");


INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp", "empFirstName", "empLastNAme", "jbuilder1994@gmail.com", 1,1,1, "231456", "empFirstName empLastNAme");
    
    
INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp1", "empFirstName1", "empLastNAme1","jbuilder1995@gmail.com", 1,2,1, "231456", "empFirstName1 empLastNAme1");
    
    
INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp2", "empFirstName2", "empLastNAme2","jbuilder1996@gmail.com", 2,3,2, "331456", "empFirstName2 empLastNAme2");
    
    
INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp3", "empFirstName3", "empLastNAme3", "jbuilder1997@gmail.com", 1,1,1, "233456", "empFirstName3 empLastNAme3");
    
    
INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp4", "empFirstName4", "empLastNAme4", "jbuilder1998@gmail.com", 2,2,2, "331466", "empFirstName4 empLastNAme4");
    
    
INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp5", "empFirstName5", "empLastNAme5", "jbuilder1998@gmail.com", 2,1,2, "331467", "empFirstName5 empLastNAme6");

INSERT INTO EMPLOYEE
	(NAME, firstname, lastname, emailaddress, SHFTPAT_ID, CALCGRP_ID, PAYGRP_ID, SIN, FULLNAME)
values
    ("emp6", "empFirstName6", "empLastNAme6", "jbuilder1998@gmail.com", 1,1,2, "331468", "empFirstName6 empLastNAme8");



insert into PAY_GROUP (PAYGRP_NAME, PAYGRP_START_DATE, PAYGRP_END_DATE, PAYGRPTYP_ID, PAYSYS_ID) 
values ("PAYGRP1", "2017-09-01", "2017-09-01",  1, 1);

insert into PAY_GROUP (PAYGRP_NAME, PAYGRP_START_DATE, PAYGRP_END_DATE, PAYGRPTYP_ID, PAYSYS_ID) 
values ("PAYGRP2", "2017-10-02", "2017-10-02",  1, 1);

insert into PAY_GROUP (PAYGRP_NAME, PAYGRP_START_DATE, PAYGRP_END_DATE, PAYGRPTYP_ID, PAYSYS_ID) 
values ("PAYGRP3", "2017-08-02", "2017-02-02",  1, 1);
