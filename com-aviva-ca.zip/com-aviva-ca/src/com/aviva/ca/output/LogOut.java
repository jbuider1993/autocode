package com.aviva.ca.output;

public class LogOut {
	public static void printlnOut(String message) {
		System.out.println(message);
	}

}
