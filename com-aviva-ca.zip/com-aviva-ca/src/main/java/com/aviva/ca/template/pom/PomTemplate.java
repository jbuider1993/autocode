package com.aviva.ca.template.pom;

import com.aviva.ca.template.Template;

public class PomTemplate extends Template {

}
