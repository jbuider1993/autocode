package com.aviva.ca.database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JDBCUtil {

	private static DatabaseMetaData metadata = null;

	private static Connection getConnection(String db_url, String db_user, String db_password) throws SQLException {
		Connection connection = DriverManager.getConnection(db_url, db_user, db_password);
		return connection;
	}
	
	public static DatabaseMetaData getMetaData(String db_url, String db_user, String db_password, String dbDriverClass) throws SQLException, ClassNotFoundException {
		//Class.forName(dbDriverClass);
		metadata = getConnection(db_url, db_user, db_password).getMetaData();
		return metadata;
	}
	
	public static ArrayList<String> getTables() throws SQLException {
		String table[] = { "TABLE", "VIEW" };
		ResultSet rs = null;
		ArrayList<String> tables = new ArrayList<>();
		rs = metadata.getTables(null, null, null, table);
		while (rs.next()) {
			tables.add(rs.getString("TABLE_NAME"));
		}
		return tables;
	}

	public static ArrayList<Map<String, String>> getColumns(String tableName) throws SQLException {
		 ResultSet columns = metadata.getColumns(null,null, tableName, null);
		 ArrayList<Map<String, String>> columnsMap = new ArrayList<>();
		 while(columns.next())
         {
			 Map<String, String> column = new HashMap<>();
			 column.put("COLUMN_NAME", columns.getString("COLUMN_NAME"));
			 column.put("DATA_TYPE",  columns.getString("DATA_TYPE"));
			 column.put("COLUMN_SIZE",  columns.getString("COLUMN_SIZE"));
			 column.put("DECIMAL_DIGITS",  columns.getString("DECIMAL_DIGITS"));
			 column.put("IS_NULLABLE",  columns.getString("IS_NULLABLE"));
			 column.put("IS_AUTOINCREMENT",  columns.getString("IS_AUTOINCREMENT"));
			 columnsMap.add(column);
         }
		 return columnsMap;
	}
	
	public static ArrayList<String> getPrimeryKeys(String tableName) throws SQLException {
		ResultSet primaryKeys = metadata.getPrimaryKeys(null,null, tableName);
		ArrayList<String> keys = new ArrayList<>();
		while(primaryKeys.next())
        {
			keys.add(primaryKeys.getString("PK_NAME"));
        }
		return keys;
	}
	
	public static ArrayList<Map<String, String>> getImportedKeys(String tableName) throws SQLException {
		 ResultSet importKeys = metadata.getImportedKeys(null, null, tableName);
		 ArrayList<Map<String, String>> keys = new ArrayList<>();
         while(importKeys.next())
         {
        	 Map<String, String> importKey = new HashMap<>();
        	 importKey.put("PKTABLE_NAME", importKeys.getString("PKTABLE_NAME"));
        	 importKey.put("PKCOLUMN_NAME", importKeys.getString("PKCOLUMN_NAME"));
        	 importKey.put("FKTABLE_NAME", importKeys.getString("FKTABLE_NAME"));
        	 importKey.put("FKCOLUMN_NAME", importKeys.getString("FKCOLUMN_NAME"));
        	 keys.add(importKey);
         }
         return keys;
	}
	
}
