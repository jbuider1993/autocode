package com.aviva.ca.template.JavaTemplate;

import com.aviva.ca.template.Template;

public class JavaTemplate extends Template {
      
}
