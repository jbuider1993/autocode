package com.aviva.ca.template.property;

import com.aviva.ca.template.Template;

public class PropertyTemplate extends Template {

}
